package com.miplus.arbicore_private

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
