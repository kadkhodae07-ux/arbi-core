#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

flutter create \
  --platforms=android \
  --org com.miplus \
  --project-name arbicore_private \
  "$TMP/arbicore_private"

rm -rf "$ROOT/android"
cp -R "$TMP/arbicore_private/android" "$ROOT/android"
cp "$ROOT/android_overrides/app/src/main/AndroidManifest.xml" "$ROOT/android/app/src/main/AndroidManifest.xml"
rm -rf "$ROOT/android/app/src/main/kotlin"
mkdir -p "$ROOT/android/app/src/main/kotlin/com/miplus/arbicore_private"
cp "$ROOT/android_overrides/app/src/main/kotlin/com/miplus/arbicore_private/MainActivity.kt" "$ROOT/android/app/src/main/kotlin/com/miplus/arbicore_private/MainActivity.kt"
cp "$ROOT/android_overrides/app/src/main/res/values/styles.xml" "$ROOT/android/app/src/main/res/values/styles.xml"

echo "Android scaffold ready: com.miplus.arbicore_private"
