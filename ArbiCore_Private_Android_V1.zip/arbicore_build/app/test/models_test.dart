import 'package:arbicore_private/models/models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('settings json roundtrip preserves one-dollar paper defaults', () {
    const value = TradingSettings(
      mode: TradeMode.paper,
      running: true,
      tradeAmountUsdc: 1,
      minNetProfitUsdc: .001,
      minNetSpreadPct: .1,
      safetyMarginPct: .05,
      slippageBudgetPct: .05,
      estimatedGasUsdc: .002,
      maxTradesPerDay: 100,
      maxDailyNotionalUsdc: 100,
      maxDailyLossUsdc: 1,
      cooldownSeconds: 5,
      scanIntervalMillis: 200,
      profitSweepEnabled: false,
      profitSweepFloorUsdc: 1,
    );
    final decoded = TradingSettings.fromJson(value.toJson());
    expect(decoded.mode, TradeMode.paper);
    expect(decoded.tradeAmountUsdc, 1);
    expect(decoded.scanIntervalMillis, 200);
  });
}
