# ArbiCore Private V1 — QA Report

Date: 2026-08-10
Scope: private single-user Android Flutter controller + Base DEX arbitrage backend/trading engine.

## Backend checks passed

- `go test ./...`
- `go test -race ./...`
- `go vet ./...`
- Linux amd64 static server build
- Paper-trading integration test through a mocked JSON-RPC path
- Correct Base USDC/WETH token-order price conversion unit tests
- JSON/YAML/XML parsing checks
- Shell script syntax checks
- Node executor syntax check (`node --check`)
- Source scan for hard-coded private-key-shaped literals
- Placeholder API/RPC secrets are rejected at backend startup
- Live mode is rejected until a valid Vault, executor URL and non-placeholder executor secret are configured
- Stop/Emergency Stop invalidates stale scans before they can submit new trades
- Daily notional/loss/trade counters persist across backend restarts
- Submitted live trades have receipt reconciliation and persistent tx idempotency

## DEX configuration reviewed

- Uniswap V3 Base adapter/configuration included.
- PancakeSwap V3 Base Factory / SwapRouter / QuoterV2 configuration included.
- PancakeSwap V3 router uses its separate `exactInputSingle` ABI adapter with `deadline`.
- PancakeSwap V3 fee tiers use 100 / 500 / 2500 / 10000.

## Android checks completed

- Flutter project source and deterministic Android bootstrap script included.
- Android Manifest XML parses successfully.
- GitHub Actions workflow YAML parses successfully.
- Reown AppKit dependency is pinned to 1.8.4 and the source follows the current package example API used for connect/account buttons.
- Backend HTTP cleartext is disabled in Android; deployment expects HTTPS.

## Important gates not executed in this environment

- Flutter SDK is not installed in the current build container, so `flutter pub get`, `flutter analyze`, `flutter test`, and APK compilation were not executed locally. The included GitHub Actions workflow runs all four steps.
- Solidity compiler / Foundry is not installed in the current build container. `PrivateArbitrageVault.sol` was manually reviewed for the V1 design but was not locally compiled or fuzz-tested. **Keep Live mode disabled until the Solidity compile/test/security-review gate passes.**
- npm dependencies are intentionally not vendored. The executor pins `viem` to 2.33.0 and Docker installs it during build.

## Live-money caution

The default is Paper mode with a 1 USDC trade size. One dollar is a functional micro-test amount, not a profitability promise. Gas, DEX fees, price impact, RPC latency, MEV/competition and transaction reverts can eliminate an apparent spread. No profit is guaranteed.
