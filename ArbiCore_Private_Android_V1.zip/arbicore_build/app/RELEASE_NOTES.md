# ArbiCore Private V1 — Release Notes

Scope: private single-user Android app + Base backend/trading engine. No website, no public registration, no CEX account integration.

## Delivered

### Android Flutter
- Persian RTL trading UI.
- Dashboard, scanner, Auto Trading, trades, wallet.
- MetaMask/compatible wallet connection via Reown AppKit.
- Persistent backend risk-setting controls.
- Scan/Paper/Live modes and Emergency Stop.
- GitHub Actions APK build workflow.

### Backend / engine
- Go 24/7 scanner and private API.
- Base `pending` RPC state.
- Uniswap V3 + PancakeSwap V3 WETH/USDC pools.
- Concurrent pool snapshots.
- Exact QuoterV2 two-leg cycle quote before execution eligibility.
- Risk engine and persisted UTC daily limits.
- Paper execution.
- Live executor with simulation, idempotency, receipt reconciliation.
- Automatic owner-only profit sweep option.

### On-chain Vault
- Immutable owner / separate operator.
- Whitelisted tokens and routers.
- Uniswap SwapRouter02 and Pancake V3 router adapters.
- Atomic two-leg cycle with on-chain minimum-profit invariant.
- Owner-only principal withdrawal and pause.
- Optional on-chain trade cap and minimum-profit floor.

## Default test profile

- Mode: Paper
- Trade amount: 1 USDC
- Scan interval: 200 ms
- Network: Base Mainnet
- Pair: USDC/WETH

`$1` is a functional micro-test target, not a guarantee that any profitable opportunity will exist after DEX fees, price impact, gas and competition.

## Validation status

Backend Go unit tests, vet, build and Node executor syntax are part of the release QA. Flutter and Solidity require their respective SDK/compiler in the build environment; do not activate Live with meaningful capital until those build/test gates pass and the contract receives an independent security review.
