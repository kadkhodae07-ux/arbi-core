import 'package:flutter/material.dart';
import 'package:reown_appkit/reown_appkit.dart';

import '../core/app_config.dart';

class WalletService {
  ReownAppKitModal? modal;

  Future<void> init(BuildContext context) async {
    if (modal != null || AppConfig.reownProjectId.isEmpty) return;
    modal = ReownAppKitModal(
      context: context,
      projectId: AppConfig.reownProjectId,
      metadata: const PairingMetadata(
        name: 'ArbiCore Private',
        description: 'Private Base arbitrage controller',
        url: 'https://arbicore.local',
        icons: [],
        redirect: Redirect(native: 'arbicore://'),
      ),
    );
    await modal!.init();
  }

  bool get isConnected => modal?.isConnected ?? false;
}
