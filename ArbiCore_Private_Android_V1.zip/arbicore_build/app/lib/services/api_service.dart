import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/app_config.dart';
import '../models/models.dart';

class ApiService {
  final http.Client _client = http.Client();

  Map<String, String> get _headers => {
        'authorization': 'Bearer ${AppConfig.apiToken}',
        'content-type': 'application/json',
      };

  Future<dynamic> _request(String method, String path, [Object? body]) async {
    final uri = Uri.parse('${AppConfig.backendUrl}$path');
    late http.Response response;
    if (method == 'GET') {
      response = await _client.get(uri, headers: _headers).timeout(const Duration(seconds: 8));
    } else if (method == 'POST') {
      response = await _client.post(uri, headers: _headers, body: body == null ? null : jsonEncode(body)).timeout(const Duration(seconds: 8));
    } else if (method == 'PUT') {
      response = await _client.put(uri, headers: _headers, body: jsonEncode(body)).timeout(const Duration(seconds: 8));
    } else {
      throw UnsupportedError(method);
    }
    if (response.statusCode ~/ 100 != 2) {
      String detail = '';
      try {
        detail = '${jsonDecode(response.body)['error'] ?? ''}';
      } catch (_) {}
      throw Exception('API ${response.statusCode}${detail.isEmpty ? '' : ': $detail'}');
    }
    return response.body.isEmpty ? null : jsonDecode(response.body);
  }

  Future<EngineStatus> status() async => EngineStatus.fromJson(await _request('GET', '/v1/status'));
  Future<MetaInfo> meta() async => MetaInfo.fromJson(await _request('GET', '/v1/meta'));
  Future<WalletState> wallet() async => WalletState.fromJson(await _request('GET', '/v1/wallet'));
  Future<TradingSettings> settings() async => TradingSettings.fromJson(await _request('GET', '/v1/settings'));
  Future<List<Opportunity>> opportunities() async => (await _request('GET', '/v1/opportunities') as List).map((e) => Opportunity.fromJson(e as Map<String, dynamic>)).toList();
  Future<List<Trade>> trades() async => (await _request('GET', '/v1/trades') as List).map((e) => Trade.fromJson(e as Map<String, dynamic>)).toList();

  Future<TradingSettings> saveSettings(TradingSettings settings) async {
    return TradingSettings.fromJson(await _request('PUT', '/v1/settings', settings.toJson()));
  }

  Future<void> start() async => _request('POST', '/v1/control/start');
  Future<void> stop() async => _request('POST', '/v1/control/stop');
}
