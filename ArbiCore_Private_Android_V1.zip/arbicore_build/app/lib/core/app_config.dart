class AppConfig {
  static const backendUrl = String.fromEnvironment('BACKEND_URL', defaultValue: 'http://10.0.2.2:8080');
  static const apiToken = String.fromEnvironment('API_TOKEN', defaultValue: '');
  static const reownProjectId = String.fromEnvironment('REOWN_PROJECT_ID', defaultValue: '');
}
