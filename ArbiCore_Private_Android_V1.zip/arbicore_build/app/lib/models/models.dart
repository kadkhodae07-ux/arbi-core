enum TradeMode { scan, paper, live }

TradeMode tradeModeFromString(String value) {
  return TradeMode.values.firstWhere(
    (m) => m.name == value,
    orElse: () => TradeMode.scan,
  );
}

class EngineStatus {
  final bool running;
  final TradeMode mode;
  final bool rpcHealthy;
  final int lastBlock;
  final double todayProfit;
  final int todayTrades;
  final double todayNotional;
  final double scanDurationMs;
  final int quoteFailures;
  final String lastError;

  const EngineStatus({
    required this.running,
    required this.mode,
    required this.rpcHealthy,
    required this.lastBlock,
    required this.todayProfit,
    required this.todayTrades,
    required this.todayNotional,
    required this.scanDurationMs,
    required this.quoteFailures,
    required this.lastError,
  });

  factory EngineStatus.fromJson(Map<String, dynamic> j) => EngineStatus(
        running: j['running'] == true,
        mode: tradeModeFromString('${j['mode'] ?? 'scan'}'),
        rpcHealthy: j['rpc_healthy'] == true,
        lastBlock: (j['last_block'] as num? ?? 0).toInt(),
        todayProfit: (j['today_net_profit_usdc'] as num? ?? 0).toDouble(),
        todayTrades: (j['today_trade_count'] as num? ?? 0).toInt(),
        todayNotional: (j['today_notional_usdc'] as num? ?? 0).toDouble(),
        scanDurationMs: (j['scan_duration_ms'] as num? ?? 0).toDouble(),
        quoteFailures: (j['quote_failures'] as num? ?? 0).toInt(),
        lastError: '${j['last_error'] ?? ''}',
      );
}

class TradingSettings {
  final TradeMode mode;
  final bool running;
  final double tradeAmountUsdc;
  final double minNetProfitUsdc;
  final double minNetSpreadPct;
  final double safetyMarginPct;
  final double slippageBudgetPct;
  final double estimatedGasUsdc;
  final int maxTradesPerDay;
  final double maxDailyNotionalUsdc;
  final double maxDailyLossUsdc;
  final int cooldownSeconds;
  final int scanIntervalMillis;
  final bool profitSweepEnabled;
  final double profitSweepFloorUsdc;

  const TradingSettings({
    required this.mode,
    required this.running,
    required this.tradeAmountUsdc,
    required this.minNetProfitUsdc,
    required this.minNetSpreadPct,
    required this.safetyMarginPct,
    required this.slippageBudgetPct,
    required this.estimatedGasUsdc,
    required this.maxTradesPerDay,
    required this.maxDailyNotionalUsdc,
    required this.maxDailyLossUsdc,
    required this.cooldownSeconds,
    required this.scanIntervalMillis,
    required this.profitSweepEnabled,
    required this.profitSweepFloorUsdc,
  });

  factory TradingSettings.fromJson(Map<String, dynamic> j) => TradingSettings(
        mode: tradeModeFromString('${j['mode'] ?? 'paper'}'),
        running: j['running'] == true,
        tradeAmountUsdc: (j['trade_amount_usdc'] as num? ?? 1).toDouble(),
        minNetProfitUsdc: (j['min_net_profit_usdc'] as num? ?? .001).toDouble(),
        minNetSpreadPct: (j['min_net_spread_pct'] as num? ?? .1).toDouble(),
        safetyMarginPct: (j['safety_margin_pct'] as num? ?? .05).toDouble(),
        slippageBudgetPct: (j['slippage_budget_pct'] as num? ?? .05).toDouble(),
        estimatedGasUsdc: (j['estimated_gas_usdc'] as num? ?? .002).toDouble(),
        maxTradesPerDay: (j['max_trades_per_day'] as num? ?? 100).toInt(),
        maxDailyNotionalUsdc: (j['max_daily_notional_usdc'] as num? ?? 100).toDouble(),
        maxDailyLossUsdc: (j['max_daily_loss_usdc'] as num? ?? 1).toDouble(),
        cooldownSeconds: (j['cooldown_seconds'] as num? ?? 5).toInt(),
        scanIntervalMillis: (j['scan_interval_millis'] as num? ?? 200).toInt(),
        profitSweepEnabled: j['profit_sweep_enabled'] == true,
        profitSweepFloorUsdc: (j['profit_sweep_floor_usdc'] as num? ?? 1).toDouble(),
      );

  Map<String, dynamic> toJson() => {
        'mode': mode.name,
        'running': running,
        'trade_amount_usdc': tradeAmountUsdc,
        'min_net_profit_usdc': minNetProfitUsdc,
        'min_net_spread_pct': minNetSpreadPct,
        'safety_margin_pct': safetyMarginPct,
        'slippage_budget_pct': slippageBudgetPct,
        'estimated_gas_usdc': estimatedGasUsdc,
        'max_trades_per_day': maxTradesPerDay,
        'max_daily_notional_usdc': maxDailyNotionalUsdc,
        'max_daily_loss_usdc': maxDailyLossUsdc,
        'cooldown_seconds': cooldownSeconds,
        'scan_interval_millis': scanIntervalMillis,
        'profit_sweep_enabled': profitSweepEnabled,
        'profit_sweep_floor_usdc': profitSweepFloorUsdc,
      };
}

class Opportunity {
  final String id;
  final String buyVenue;
  final String sellVenue;
  final String rejectReason;
  final String quoteError;
  final double raw;
  final double net;
  final double profit;
  final double amount;
  final double buyPrice;
  final double sellPrice;
  final double cycleOut;
  final bool quoteOk;
  final bool executable;

  Opportunity.fromJson(Map<String, dynamic> j)
      : id = '${j['id'] ?? ''}',
        buyVenue = '${j['buy_venue'] ?? ''}',
        sellVenue = '${j['sell_venue'] ?? ''}',
        rejectReason = '${j['reject_reason'] ?? ''}',
        quoteError = '${j['quote_error'] ?? ''}',
        raw = (j['raw_spread_pct'] as num? ?? 0).toDouble(),
        net = (j['estimated_net_pct'] as num? ?? 0).toDouble(),
        profit = (j['estimated_net_usdc'] as num? ?? 0).toDouble(),
        amount = (j['trade_amount_usdc'] as num? ?? 0).toDouble(),
        buyPrice = (j['buy_price_usdc'] as num? ?? 0).toDouble(),
        sellPrice = (j['sell_price_usdc'] as num? ?? 0).toDouble(),
        cycleOut = (j['quoted_cycle_out_usdc'] as num? ?? 0).toDouble(),
        quoteOk = j['quote_ok'] == true,
        executable = j['executable'] == true;
}

class Trade {
  final String id;
  final String status;
  final TradeMode mode;
  final String buyVenue;
  final String sellVenue;
  final String txHash;
  final double amount;
  final double expected;
  final double realized;

  Trade.fromJson(Map<String, dynamic> j)
      : id = '${j['id'] ?? ''}',
        status = '${j['status'] ?? ''}',
        mode = tradeModeFromString('${j['mode'] ?? 'scan'}'),
        buyVenue = '${j['buy_venue'] ?? ''}',
        sellVenue = '${j['sell_venue'] ?? ''}',
        txHash = '${j['tx_hash'] ?? ''}',
        amount = (j['amount_usdc'] as num? ?? 0).toDouble(),
        expected = (j['expected_profit_usdc'] as num? ?? 0).toDouble(),
        realized = (j['realized_profit_usdc'] as num? ?? 0).toDouble();
}

class MetaInfo {
  final String chainName;
  final String usdc;
  final String vault;
  final String rpcBlockTag;
  final int chainId;

  MetaInfo.fromJson(Map<String, dynamic> j)
      : chainName = '${j['chain_name'] ?? ''}',
        usdc = '${j['usdc'] ?? ''}',
        vault = '${j['vault_address'] ?? ''}',
        rpcBlockTag = '${j['rpc_block_tag'] ?? 'pending'}',
        chainId = (j['chain_id'] as num? ?? 0).toInt();
}

class WalletState {
  final bool configured;
  final String vault;
  final String usdc;
  final double balance;
  final String error;

  WalletState.fromJson(Map<String, dynamic> j)
      : configured = j['configured'] == true,
        vault = '${j['vault_address'] ?? ''}',
        usdc = '${j['usdc'] ?? ''}',
        balance = (j['usdc_balance'] as num? ?? 0).toDouble(),
        error = '${j['error'] ?? ''}';
}
