import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:reown_appkit/reown_appkit.dart';

import 'core/app_config.dart';
import 'models/models.dart';
import 'services/api_service.dart';
import 'services/wallet_service.dart';
import 'widgets/ui.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ArbiCoreApp());
}

class ArbiCoreApp extends StatelessWidget {
  const ArbiCoreApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'ArbiCore Private',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: const Color(0xff0a0f14),
          colorScheme: const ColorScheme.dark(
            primary: Color(0xff55e6a5),
            secondary: Color(0xff66a3ff),
            surface: Color(0xff121a22),
          ),
          navigationBarTheme: const NavigationBarThemeData(
            backgroundColor: Color(0xff0e151c),
            indicatorColor: Color(0x3355e6a5),
          ),
          cardTheme: CardThemeData(
            color: const Color(0xff121a22),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
        ),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final api = ApiService();
  final walletService = WalletService();
  int index = 0;
  EngineStatus? status;
  MetaInfo? meta;
  WalletState? walletState;
  TradingSettings? settings;
  List<Opportunity> opportunities = [];
  List<Trade> trades = [];
  Timer? timer;
  String error = '';
  bool refreshing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await walletService.init(context);
        if (mounted) setState(() {});
      } catch (e) {
        if (mounted) setState(() => error = 'Wallet: $e');
      }
      await refresh();
      timer = Timer.periodic(const Duration(seconds: 2), (_) => refresh());
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> refresh() async {
    if (refreshing || AppConfig.apiToken.isEmpty) return;
    refreshing = true;
    try {
      final r = await Future.wait([
        api.status(),
        api.meta(),
        api.wallet(),
        api.settings(),
        api.opportunities(),
        api.trades(),
      ]);
      if (!mounted) return;
      setState(() {
        status = r[0] as EngineStatus;
        meta = r[1] as MetaInfo;
        walletState = r[2] as WalletState;
        settings = r[3] as TradingSettings;
        opportunities = r[4] as List<Opportunity>;
        trades = r[5] as List<Trade>;
        error = '';
      });
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    } finally {
      refreshing = false;
    }
  }

  Future<void> saveSettings(TradingSettings value) async {
    final saved = await api.saveSettings(value);
    if (!mounted) return;
    setState(() => settings = saved);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تنظیمات ذخیره شد')));
    await refresh();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(
        status: status,
        error: error,
        opportunities: opportunities,
        trades: trades,
        walletState: walletState,
        onRefresh: refresh,
        onStart: () async { await api.start(); await refresh(); },
        onStop: () async { await api.stop(); await refresh(); },
      ),
      ScannerPage(opportunities: opportunities, onRefresh: refresh),
      AutoPage(
        status: status,
        settings: settings,
        onSave: saveSettings,
        onStart: () async { await api.start(); await refresh(); },
        onStop: () async { await api.stop(); await refresh(); },
      ),
      TradesPage(trades: trades, onRefresh: refresh),
      WalletPage(meta: meta, state: walletState, walletService: walletService),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ArbiCore Private', style: TextStyle(fontWeight: FontWeight.w900)),
          backgroundColor: Colors.transparent,
          actions: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Center(
                child: Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (status?.rpcHealthy ?? false) ? const Color(0xff55e6a5) : Colors.redAccent,
                  ),
                ),
              ),
            ),
          ],
        ),
        body: SafeArea(
          child: AppConfig.apiToken.isEmpty
              ? const _MissingConfig()
              : IndexedStack(index: index, children: pages),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard_rounded), label: 'داشبورد'),
            NavigationDestination(icon: Icon(Icons.radar_rounded), label: 'اسکنر'),
            NavigationDestination(icon: Icon(Icons.bolt_rounded), label: 'خودکار'),
            NavigationDestination(icon: Icon(Icons.swap_horiz_rounded), label: 'معاملات'),
            NavigationDestination(icon: Icon(Icons.account_balance_wallet_rounded), label: 'کیف پول'),
          ],
        ),
      ),
    );
  }
}

class _MissingConfig extends StatelessWidget {
  const _MissingConfig();
  @override
  Widget build(BuildContext context) => const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'API_TOKEN هنگام Build تنظیم نشده است. نسخه خصوصی باید با BACKEND_URL و API_TOKEN ساخته شود.',
            textAlign: TextAlign.center,
          ),
        ),
      );
}

class DashboardPage extends StatelessWidget {
  final EngineStatus? status;
  final String error;
  final List<Opportunity> opportunities;
  final List<Trade> trades;
  final WalletState? walletState;
  final Future<void> Function() onRefresh;
  final Future<void> Function() onStart;
  final Future<void> Function() onStop;

  const DashboardPage({
    super.key,
    required this.status,
    required this.error,
    required this.opportunities,
    required this.trades,
    required this.walletState,
    required this.onRefresh,
    required this.onStart,
    required this.onStop,
  });

  @override
  Widget build(BuildContext context) {
    final s = status;
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xff173129), Color(0xff102338)]),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        (s?.running ?? false) ? 'موتور فعال 24/7' : 'موتور متوقف',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'حالت: ${(s?.mode.name ?? '--').toUpperCase()} • بلوک ${s?.lastBlock ?? 0}',
                        style: const TextStyle(color: Colors.white60),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: s?.running ?? false,
                  onChanged: (_) => (s?.running ?? false) ? onStop() : onStart(),
                ),
              ],
            ),
          ),
          if (error.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(error, style: const TextStyle(color: Colors.redAccent)),
            ),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.35,
            children: [
              MetricCard(label: 'موجودی Vault', value: '\$${(walletState?.balance ?? 0).toStringAsFixed(4)}', icon: Icons.account_balance_wallet),
              MetricCard(label: 'سود امروز', value: '\$${(s?.todayProfit ?? 0).toStringAsFixed(4)}', icon: Icons.trending_up),
              MetricCard(label: 'معاملات امروز', value: '${s?.todayTrades ?? 0}', icon: Icons.bolt),
              MetricCard(label: 'زمان اسکن', value: '${(s?.scanDurationMs ?? 0).toStringAsFixed(1)} ms', icon: Icons.speed_rounded),
            ],
          ),
          const SectionTitle('فرصت‌های قابل اجرا'),
          ...opportunities.where((o) => o.executable).take(3).map((o) => OpportunityTile(o: o)),
          if (!opportunities.any((o) => o.executable))
            const Text('فعلاً فرصت قابل اجرای تأییدشده‌ای وجود ندارد.', style: TextStyle(color: Colors.white54)),
          const SectionTitle('آخرین معاملات'),
          ...trades.take(3).map((t) => TradeTile(t: t)),
        ],
      ),
    );
  }
}

class ScannerPage extends StatelessWidget {
  final List<Opportunity> opportunities;
  final Future<void> Function() onRefresh;
  const ScannerPage({super.key, required this.opportunities, required this.onRefresh});

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('اسکن شکاف قیمت', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text(
              'فرصت‌های جدی با Quoter چرخه کامل بررسی می‌شوند؛ Net شامل Gas و حاشیه‌های ایمنی تنظیم‌شده است.',
              style: TextStyle(color: Colors.white54),
            ),
            const SizedBox(height: 14),
            ...opportunities.map((o) => OpportunityTile(o: o)),
            if (opportunities.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 32),
                child: Center(child: Text('داده‌ای ثبت نشده است.', style: TextStyle(color: Colors.white54))),
              ),
          ],
        ),
      );
}

class OpportunityTile extends StatelessWidget {
  final Opportunity o;
  const OpportunityTile({super.key, required this.o});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(child: Text('${o.buyVenue} ← ${o.sellVenue}', style: const TextStyle(fontWeight: FontWeight.w800))),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(
                      color: o.executable ? const Color(0x2255e6a5) : Colors.white10,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      o.executable ? 'قابل اجرا' : 'رد شده',
                      style: TextStyle(color: o.executable ? const Color(0xff55e6a5) : Colors.white54, fontSize: 11),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('خام ${o.raw.toStringAsFixed(3)}%'),
                  Text('خالص ${o.net.toStringAsFixed(3)}%', style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text('\$${o.profit.toStringAsFixed(4)}'),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('حجم \$${o.amount.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
                  Text(o.quoteOk ? 'Exact Quote ✓' : 'Spot precheck', style: TextStyle(color: o.quoteOk ? const Color(0xff55e6a5) : Colors.white38, fontSize: 11)),
                ],
              ),
              if (o.rejectReason.isNotEmpty || o.quoteError.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      o.rejectReason.isNotEmpty ? o.rejectReason : o.quoteError,
                      style: const TextStyle(color: Colors.white38, fontSize: 11),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
}

class TradesPage extends StatelessWidget {
  final List<Trade> trades;
  final Future<void> Function() onRefresh;
  const TradesPage({super.key, required this.trades, required this.onRefresh});

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('تاریخچه معاملات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            ...trades.map((t) => TradeTile(t: t)),
            if (trades.isEmpty) const Center(child: Text('هنوز معامله‌ای ثبت نشده است.', style: TextStyle(color: Colors.white54))),
          ],
        ),
      );
}

class TradeTile extends StatelessWidget {
  final Trade t;
  const TradeTile({super.key, required this.t});

  @override
  Widget build(BuildContext context) {
    final p = t.realized != 0 ? t.realized : t.expected;
    return Card(
      child: ListTile(
        title: Text('${t.buyVenue} → ${t.sellVenue}', style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('${t.mode.name.toUpperCase()} • ${t.status} • \$${t.amount.toStringAsFixed(2)}'),
        trailing: Text(
          '\$${p.toStringAsFixed(4)}',
          style: TextStyle(fontWeight: FontWeight.w900, color: p >= 0 ? const Color(0xff55e6a5) : Colors.redAccent),
        ),
      ),
    );
  }
}

class AutoPage extends StatelessWidget {
  final EngineStatus? status;
  final TradingSettings? settings;
  final Future<void> Function(TradingSettings) onSave;
  final Future<void> Function() onStart;
  final Future<void> Function() onStop;

  const AutoPage({super.key, required this.status, required this.settings, required this.onSave, required this.onStart, required this.onStop});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Auto Trading', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('برای شروع، Paper بماند. Live فقط بعد از Deploy و تنظیم Vault/Executor فعال شود.', style: TextStyle(color: Colors.white54)),
          const SizedBox(height: 16),
          Card(
            child: SwitchListTile(
              value: status?.running ?? false,
              title: const Text('موتور 24/7'),
              subtitle: Text(status?.running == true ? 'فعال روی VPS' : 'متوقف'),
              onChanged: (v) => v ? onStart() : onStop(),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
            onPressed: status?.running == true ? onStop : null,
            icon: const Icon(Icons.emergency_rounded),
            label: const Text('EMERGENCY STOP'),
          ),
          const SizedBox(height: 18),
          if (settings != null) SettingsEditor(initial: settings!, onSave: onSave),
        ],
      );
}

class SettingsEditor extends StatefulWidget {
  final TradingSettings initial;
  final Future<void> Function(TradingSettings) onSave;
  const SettingsEditor({super.key, required this.initial, required this.onSave});

  @override
  State<SettingsEditor> createState() => _SettingsEditorState();
}

class _SettingsEditorState extends State<SettingsEditor> {
  late TradeMode mode;
  late bool sweep;
  late final Map<String, TextEditingController> c;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    mode = widget.initial.mode;
    sweep = widget.initial.profitSweepEnabled;
    c = {
      'amount': TextEditingController(text: '${widget.initial.tradeAmountUsdc}'),
      'minProfit': TextEditingController(text: '${widget.initial.minNetProfitUsdc}'),
      'minSpread': TextEditingController(text: '${widget.initial.minNetSpreadPct}'),
      'safety': TextEditingController(text: '${widget.initial.safetyMarginPct}'),
      'slippage': TextEditingController(text: '${widget.initial.slippageBudgetPct}'),
      'gas': TextEditingController(text: '${widget.initial.estimatedGasUsdc}'),
      'maxTrades': TextEditingController(text: '${widget.initial.maxTradesPerDay}'),
      'maxNotional': TextEditingController(text: '${widget.initial.maxDailyNotionalUsdc}'),
      'maxLoss': TextEditingController(text: '${widget.initial.maxDailyLossUsdc}'),
      'cooldown': TextEditingController(text: '${widget.initial.cooldownSeconds}'),
      'interval': TextEditingController(text: '${widget.initial.scanIntervalMillis}'),
      'sweepFloor': TextEditingController(text: '${widget.initial.profitSweepFloorUsdc}'),
    };
  }

  @override
  void dispose() {
    for (final x in c.values) x.dispose();
    super.dispose();
  }

  double d(String key) => double.tryParse(c[key]!.text.trim()) ?? -1;
  int i(String key) => int.tryParse(c[key]!.text.trim()) ?? -1;

  Future<void> chooseMode(TradeMode next) async {
    if (next == TradeMode.live && mode != TradeMode.live) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('فعال‌سازی LIVE'),
          content: const Text('LIVE تراکنش واقعی ارسال می‌کند. فقط پس از Deploy Vault، تنظیم Operator و تست Paper آن را فعال کن.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تأیید LIVE')),
          ],
        ),
      );
      if (ok != true) return;
    }
    setState(() => mode = next);
  }

  Future<void> save() async {
    final next = TradingSettings(
      mode: mode,
      running: widget.initial.running,
      tradeAmountUsdc: d('amount'),
      minNetProfitUsdc: d('minProfit'),
      minNetSpreadPct: d('minSpread'),
      safetyMarginPct: d('safety'),
      slippageBudgetPct: d('slippage'),
      estimatedGasUsdc: d('gas'),
      maxTradesPerDay: i('maxTrades'),
      maxDailyNotionalUsdc: d('maxNotional'),
      maxDailyLossUsdc: d('maxLoss'),
      cooldownSeconds: i('cooldown'),
      scanIntervalMillis: i('interval'),
      profitSweepEnabled: sweep,
      profitSweepFloorUsdc: d('sweepFloor'),
    );
    setState(() => saving = true);
    try {
      await widget.onSave(next);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطا در ذخیره: $e')));
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SectionTitle('حالت اجرا'),
          SegmentedButton<TradeMode>(
            segments: const [
              ButtonSegment(value: TradeMode.scan, label: Text('SCAN')),
              ButtonSegment(value: TradeMode.paper, label: Text('PAPER')),
              ButtonSegment(value: TradeMode.live, label: Text('LIVE')),
            ],
            selected: {mode},
            onSelectionChanged: (v) => chooseMode(v.first),
          ),
          const SectionTitle('سرمایه و سود'),
          NumberSettingField(controller: c['amount']!, label: 'حجم هر معامله', suffix: 'USDC'),
          const SizedBox(height: 10),
          NumberSettingField(controller: c['minProfit']!, label: 'حداقل سود خالص', suffix: 'USDC'),
          const SizedBox(height: 10),
          NumberSettingField(controller: c['minSpread']!, label: 'حداقل Spread خالص', suffix: '%'),
          const SectionTitle('هزینه و حاشیه ایمنی'),
          NumberSettingField(controller: c['safety']!, label: 'Safety Margin', suffix: '%'),
          const SizedBox(height: 10),
          NumberSettingField(controller: c['slippage']!, label: 'Slippage Budget', suffix: '%'),
          const SizedBox(height: 10),
          NumberSettingField(controller: c['gas']!, label: 'Gas Budget تقریبی', suffix: 'USDC'),
          const SectionTitle('محدودیت روزانه'),
          NumberSettingField(controller: c['maxTrades']!, label: 'حداکثر تعداد معاملات', integer: true),
          const SizedBox(height: 10),
          NumberSettingField(controller: c['maxNotional']!, label: 'حداکثر حجم روزانه', suffix: 'USDC'),
          const SizedBox(height: 10),
          NumberSettingField(controller: c['maxLoss']!, label: 'حداکثر ضرر روزانه', suffix: 'USDC'),
          const SectionTitle('سرعت'),
          NumberSettingField(controller: c['interval']!, label: 'فاصله اسکن', suffix: 'ms', integer: true),
          const SizedBox(height: 10),
          NumberSettingField(controller: c['cooldown']!, label: 'Cooldown معامله', suffix: 'sec', integer: true),
          const SectionTitle('برگشت سود به کیف پول مالک'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: sweep,
            onChanged: (v) => setState(() => sweep = v),
            title: const Text('Auto Profit Sweep'),
            subtitle: const Text('فقط مازاد بالاتر از Principal Floor به مالک Vault منتقل می‌شود.'),
          ),
          if (sweep) NumberSettingField(controller: c['sweepFloor']!, label: 'Principal Floor', suffix: 'USDC'),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: saving ? null : save,
            icon: saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.save_rounded),
            label: const Text('ذخیره تنظیمات'),
          ),
        ],
      );
}

class WalletPage extends StatelessWidget {
  final MetaInfo? meta;
  final WalletState? state;
  final WalletService walletService;
  const WalletPage({super.key, required this.meta, required this.state, required this.walletService});

  @override
  Widget build(BuildContext context) {
    final modal = walletService.modal;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('کیف پول و Vault', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Text('${meta?.chainName ?? 'Base'} • Chain ${meta?.chainId ?? 8453} • ${meta?.rpcBlockTag ?? 'pending'}', style: const TextStyle(color: Colors.white54)),
        const SizedBox(height: 16),
        if (AppConfig.reownProjectId.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('REOWN_PROJECT_ID تنظیم نشده؛ برای اتصال MetaMask آن را هنگام Build وارد کن.'))),
        if (modal != null) ...[
          AppKitModalConnectButton(appKit: modal, context: context),
          const SizedBox(height: 10),
          if (modal.isConnected) AppKitModalAccountButton(appKitModal: modal, context: context),
        ],
        const SectionTitle('Private Trading Vault'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('موجودی: \$${(state?.balance ?? 0).toStringAsFixed(6)} USDC', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                const Text('USDC را مستقیم از کیف پول خودت به Vault بفرست؛ سرمایه وارد CEX نمی‌شود.', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 10),
                SelectableText(
                  state?.configured == true ? state!.vault : 'Vault هنوز در Backend تنظیم نشده',
                  style: const TextStyle(fontFamily: 'monospace'),
                ),
                const SizedBox(height: 10),
                FilledButton.tonalIcon(
                  onPressed: state?.configured == true
                      ? () {
                          Clipboard.setData(ClipboardData(text: state!.vault));
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('آدرس Vault کپی شد')));
                        }
                      : null,
                  icon: const Icon(Icons.copy_rounded),
                  label: const Text('کپی آدرس Vault'),
                ),
                if (state?.error.isNotEmpty == true)
                  Padding(padding: const EdgeInsets.only(top: 10), child: Text(state!.error, style: const TextStyle(color: Colors.redAccent))),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(14),
            child: Text(
              'کلید خصوصی MetaMask در اپ یا VPS ذخیره نمی‌شود. Operator سرور فقط از Vault برای Router/Tokenهای مجاز استفاده می‌کند و برداشت اصل سرمایه فقط دست مالک Vault است.',
              style: TextStyle(color: Colors.white60),
            ),
          ),
        ),
      ],
    );
  }
}
