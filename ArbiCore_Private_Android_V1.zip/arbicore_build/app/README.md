# ArbiCore Private Android V1

Private Flutter controller for the ArbiCore Base DEX arbitrage backend. Trading runs on the VPS; closing the app does not stop the backend unless you explicitly use the Stop/Emergency Stop control.

## Included UI

- RTL Persian dark trading dashboard.
- Backend/RPC health and current mode.
- Vault USDC balance.
- Today P&L / notional / trade count.
- Live opportunity scanner with exact-quote status, raw/net spread and reject reason.
- Scan / Paper / Live mode selector with an explicit Live warning.
- Engine Start/Stop and Emergency Stop.
- Editable persistent risk settings:
  - trade amount;
  - minimum net profit;
  - minimum net spread;
  - safety margin;
  - slippage budget;
  - conservative gas budget;
  - daily trade/notional/loss limits;
  - scan interval;
  - cooldown;
  - automatic profit sweep and principal floor.
- Trade history.
- MetaMask/compatible wallet connection through Reown AppKit.
- Vault address/balance and copy action for funding from the connected wallet.

## Build-time private configuration

```bash
flutter build apk --release \
  --dart-define=BACKEND_URL=https://YOUR_PRIVATE_API_HOST \
  --dart-define=API_TOKEN=YOUR_LONG_PRIVATE_API_TOKEN \
  --dart-define=REOWN_PROJECT_ID=YOUR_REOWN_PROJECT_ID
```

The app intentionally refuses to operate without `API_TOKEN`.

## Android scaffold

The repository keeps only deterministic Android overrides. Generate the current Flutter Android scaffold before building:

```bash
bash scripts/bootstrap_android.sh
flutter pub get
flutter analyze
flutter test
flutter build apk --release ...
```

The supplied GitHub Actions workflow performs these steps automatically.

Package name:

```text
com.miplus.arbicore_private
```

Deep-link return scheme:

```text
arbicore://
```

## Wallet model

The wallet connection is for ownership/funding convenience. The MetaMask seed/private key is **not** stored in the app or sent to the backend.

For V1, funding is intentionally explicit: copy the Vault address and send native Base USDC from your wallet. This avoids giving the mobile app arbitrary automated spending authority.

## Security

- Use HTTPS for the backend endpoint.
- Prefer VPN/Tailscale/Cloudflare Access or equivalent private access in addition to the Bearer token.
- The API token is embedded in a private APK at build time and can be extracted by someone who obtains the APK; rotate it if the APK leaks.
- Keep Live mode disabled until the Vault and executor are deployed/tested.
- The on-chain Vault owner pause is stronger than the app-level Emergency Stop and should be used if the operator key is suspected compromised.
